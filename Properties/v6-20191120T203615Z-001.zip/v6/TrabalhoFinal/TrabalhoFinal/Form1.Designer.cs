﻿namespace TrabalhoFinal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lb_fluxo = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.conexãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configurarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recuperaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dadoÚnicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gráficoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gráficoTempoRealToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bt_connect = new System.Windows.Forms.Button();
            this.lb_nivelsup = new System.Windows.Forms.Label();
            this.lb_torque = new System.Windows.Forms.Label();
            this.lb_freq = new System.Windows.Forms.Label();
            this.lb_agua = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bt_motor = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lb_color = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.track_freq = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.track_freq)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(768, 575);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lb_fluxo
            // 
            this.lb_fluxo.BackColor = System.Drawing.Color.Green;
            this.lb_fluxo.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_fluxo.Location = new System.Drawing.Point(125, 56);
            this.lb_fluxo.Name = "lb_fluxo";
            this.lb_fluxo.Size = new System.Drawing.Size(85, 26);
            this.lb_fluxo.TabIndex = 1;
            this.lb_fluxo.Text = "0";
            this.lb_fluxo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.conexãoToolStripMenuItem,
            this.recuperaçãoToolStripMenuItem,
            this.gráficoTempoRealToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(768, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // conexãoToolStripMenuItem
            // 
            this.conexãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.configurarToolStripMenuItem});
            this.conexãoToolStripMenuItem.Name = "conexãoToolStripMenuItem";
            this.conexãoToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.conexãoToolStripMenuItem.Text = "Conexão";
            // 
            // configurarToolStripMenuItem
            // 
            this.configurarToolStripMenuItem.Name = "configurarToolStripMenuItem";
            this.configurarToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.configurarToolStripMenuItem.Text = "Configurar";
            this.configurarToolStripMenuItem.Click += new System.EventHandler(this.configurarToolStripMenuItem_Click);
            // 
            // recuperaçãoToolStripMenuItem
            // 
            this.recuperaçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dadoÚnicoToolStripMenuItem,
            this.gráficoToolStripMenuItem});
            this.recuperaçãoToolStripMenuItem.Name = "recuperaçãoToolStripMenuItem";
            this.recuperaçãoToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.recuperaçãoToolStripMenuItem.Text = "Recuperação";
            // 
            // dadoÚnicoToolStripMenuItem
            // 
            this.dadoÚnicoToolStripMenuItem.Name = "dadoÚnicoToolStripMenuItem";
            this.dadoÚnicoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dadoÚnicoToolStripMenuItem.Text = "Dado Único";
            this.dadoÚnicoToolStripMenuItem.Click += new System.EventHandler(this.dadoÚnicoToolStripMenuItem_Click);
            // 
            // gráficoToolStripMenuItem
            // 
            this.gráficoToolStripMenuItem.Name = "gráficoToolStripMenuItem";
            this.gráficoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.gráficoToolStripMenuItem.Text = "Gráfico";
            this.gráficoToolStripMenuItem.Click += new System.EventHandler(this.gráficoToolStripMenuItem_Click);
            // 
            // gráficoTempoRealToolStripMenuItem
            // 
            this.gráficoTempoRealToolStripMenuItem.Name = "gráficoTempoRealToolStripMenuItem";
            this.gráficoTempoRealToolStripMenuItem.Size = new System.Drawing.Size(123, 20);
            this.gráficoTempoRealToolStripMenuItem.Text = "Gráfico Tempo Real";
            this.gráficoTempoRealToolStripMenuItem.Click += new System.EventHandler(this.gráficoTempoRealToolStripMenuItem_Click);
            // 
            // bt_connect
            // 
            this.bt_connect.Location = new System.Drawing.Point(650, 45);
            this.bt_connect.Name = "bt_connect";
            this.bt_connect.Size = new System.Drawing.Size(110, 23);
            this.bt_connect.TabIndex = 3;
            this.bt_connect.Text = "CONECTAR";
            this.bt_connect.UseVisualStyleBackColor = true;
            this.bt_connect.Click += new System.EventHandler(this.bt_connect_Click);
            // 
            // lb_nivelsup
            // 
            this.lb_nivelsup.BackColor = System.Drawing.Color.Transparent;
            this.lb_nivelsup.Location = new System.Drawing.Point(436, 156);
            this.lb_nivelsup.Name = "lb_nivelsup";
            this.lb_nivelsup.Size = new System.Drawing.Size(54, 31);
            this.lb_nivelsup.TabIndex = 4;
            this.lb_nivelsup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_torque
            // 
            this.lb_torque.Location = new System.Drawing.Point(291, 530);
            this.lb_torque.Name = "lb_torque";
            this.lb_torque.Size = new System.Drawing.Size(78, 31);
            this.lb_torque.TabIndex = 5;
            this.lb_torque.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_freq
            // 
            this.lb_freq.Location = new System.Drawing.Point(207, 530);
            this.lb_freq.Name = "lb_freq";
            this.lb_freq.Size = new System.Drawing.Size(78, 31);
            this.lb_freq.TabIndex = 6;
            this.lb_freq.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_agua
            // 
            this.lb_agua.BackColor = System.Drawing.Color.White;
            this.lb_agua.Location = new System.Drawing.Point(445, 76);
            this.lb_agua.Name = "lb_agua";
            this.lb_agua.Size = new System.Drawing.Size(35, 100);
            this.lb_agua.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Aqua;
            this.label2.Location = new System.Drawing.Point(445, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 100);
            this.label2.TabIndex = 8;
            // 
            // bt_motor
            // 
            this.bt_motor.Location = new System.Drawing.Point(294, 399);
            this.bt_motor.Name = "bt_motor";
            this.bt_motor.Size = new System.Drawing.Size(75, 23);
            this.bt_motor.TabIndex = 9;
            this.bt_motor.Text = "ACIONAR";
            this.bt_motor.UseVisualStyleBackColor = true;
            this.bt_motor.Click += new System.EventHandler(this.bt_motor_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lb_color
            // 
            this.lb_color.BackColor = System.Drawing.Color.Red;
            this.lb_color.Location = new System.Drawing.Point(316, 468);
            this.lb_color.Name = "lb_color";
            this.lb_color.Size = new System.Drawing.Size(15, 15);
            this.lb_color.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(207, 561);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 23);
            this.label1.TabIndex = 11;
            this.label1.Text = "Frequência";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(291, 561);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 23);
            this.label3.TabIndex = 12;
            this.label3.Text = "Torque";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // track_freq
            // 
            this.track_freq.LargeChange = 10;
            this.track_freq.Location = new System.Drawing.Point(12, 539);
            this.track_freq.Maximum = 60;
            this.track_freq.Minimum = 10;
            this.track_freq.Name = "track_freq";
            this.track_freq.Size = new System.Drawing.Size(189, 45);
            this.track_freq.SmallChange = 10;
            this.track_freq.TabIndex = 13;
            this.track_freq.TickFrequency = 10;
            this.track_freq.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.track_freq.Value = 10;
            this.track_freq.ValueChanged += new System.EventHandler(this.track_freq_Scroll);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(768, 599);
            this.Controls.Add(this.track_freq);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_color);
            this.Controls.Add(this.bt_motor);
            this.Controls.Add(this.lb_nivelsup);
            this.Controls.Add(this.lb_agua);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lb_freq);
            this.Controls.Add(this.lb_torque);
            this.Controls.Add(this.bt_connect);
            this.Controls.Add(this.lb_fluxo);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Supervisório";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.track_freq)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lb_fluxo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem conexãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configurarToolStripMenuItem;
        private System.Windows.Forms.Button bt_connect;
        private System.Windows.Forms.Label lb_nivelsup;
        private System.Windows.Forms.Label lb_torque;
        private System.Windows.Forms.Label lb_freq;
        private System.Windows.Forms.Label lb_agua;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bt_motor;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem recuperaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dadoÚnicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gráficoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gráficoTempoRealToolStripMenuItem;
        private System.Windows.Forms.Label lb_color;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar track_freq;
    }
}

