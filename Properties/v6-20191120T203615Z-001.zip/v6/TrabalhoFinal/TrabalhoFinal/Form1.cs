﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using EasyModbus;
using Newtonsoft.Json;

namespace TrabalhoFinal
{
    /* Este formulário tem como objetivo ser o formulário principal do supervisório
     */
    public partial class Form1 : Form
    {
        private ModbusClient modbus;    //Objeto ModBus, responsável pela conexão do supervisório

        private List<Grafico> graficos;

        /* Função do construtor do formulário: inicializa o form, instancia novo ModBus e ajusta transparência
         * da label de nível
         * Entradas: nenhuma
         * Saídas: nenhuma
         */


        public Form1()
        {
            InitializeComponent();
            modbus = new ModbusClient();
            lb_nivelsup.Parent = pictureBox1;
            lb_nivelsup.BackColor = Color.Transparent;
            graficos = new List<Grafico>();
        }

        /* Função referente ao evento do clique em "Conexão>Configurar": Cria um form de configuração e chama ele
         * Entradas: padrão
         * Saídas: nenhuma
         */
        private void configurarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormConfigModbus janela = new FormConfigModbus(modbus, timer1);
            janela.Show();
        }

        /* Função referente ao evento do clique no botão "CONECTAR" ou "DESCONECTAR": 
         * Testa a ação desejada (conectar ou desconectar): Se conectar, habilita conexão do ModBus e habilita o timer
         * Se desconectar, desabilita o timer e finaliza a conexão com o ModBus
         * Entradas: padrão
         * Saídas: nenhuma
         */
        private void bt_connect_Click(object sender, EventArgs e)
        {
            if (bt_connect.Text == "CONECTAR")
            {
                try
                {
                    modbus.Connect();
                    bt_connect.Text = "DESCONECTAR";
                    timer1.Enabled = true;
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
            }
            else
            {
                bt_connect.Text = "CONECTAR";
                timer1.Enabled = false;
                modbus.Disconnect();
            }
        }

        /* Função referente ao tick do timer1: Executa em taxa pré-determinada e invoca a Thread da interface gráfica.
         * Entradas: padrão
         * Saídas: nenhuma
         */
        private void timer1_Tick(object sender, EventArgs e)
        {
            Thread ig = new Thread(interface_leitura_escrita);
            try
            {
                ig.Start();
            }
            catch (Exception ex)
            {
                timer1.Enabled = false;
                bt_connect.Text = "INICIAR";
                MessageBox.Show("Erro" + ex.Message);
            }
        }

        /* Função referente à Thread da interface gráfica, leitura e e
         * scrita de dados: Lê e atualiza as 
         * labels da interface gráfica: Flixo, nível, torque e frequência.
         * Escreve esses dados no arquivo.
         * Entradas: padrão
         * Saídas: nenhuma
         */
        private void interface_leitura_escrita()
        {
            int addressFluxo = 712;
            int addressNivel = 714;
            int addressTorque = 1334;
            int addressFreq = 1313;
            int addressSoft = 1316;
            int addressInversor = 1312;
            int addressDireta = 1319;

            int[] fluxoInt = modbus.ReadHoldingRegisters(addressFluxo, 2);
            float fluxo = ModbusClient.ConvertRegistersToFloat(fluxoInt, ModbusClient.RegisterOrder.LowHigh);
            this.Invoke((MethodInvoker)delegate { lb_fluxo.Text = fluxo.ToString(); }); // executado na thread do formulário.

            int[] NivelInt = modbus.ReadHoldingRegisters(addressNivel, 2);
            float Nivel = ModbusClient.ConvertRegistersToFloat(NivelInt, ModbusClient.RegisterOrder.LowHigh);
            this.Invoke((MethodInvoker)delegate { lb_nivelsup.Text = Nivel.ToString(); }); // executado na thread do formulário.
            this.Invoke((MethodInvoker)delegate { lb_agua.Height = (int)(100 * (1 - (Nivel / 100))); }); // executado na thread do formulário.

            int[] TorqueInt = modbus.ReadHoldingRegisters(addressTorque, 2);
            float Torque = ModbusClient.ConvertRegistersToFloat(TorqueInt, ModbusClient.RegisterOrder.LowHigh);
            this.Invoke((MethodInvoker)delegate { lb_torque.Text = Torque.ToString(); }); // executado na thread do formulário.

            int[] FreqInt = modbus.ReadHoldingRegisters(addressFreq, 1);
            this.Invoke((MethodInvoker)delegate { track_freq.Value = (FreqInt[0] / 10); }); // executado na thread do formulário.
            this.Invoke((MethodInvoker)delegate { lb_freq.Text = (FreqInt[0] / 10).ToString(); }); // executado na thread do formulário.

            int[] Soft = modbus.ReadHoldingRegisters(addressSoft, 1);
            int[] Inv = modbus.ReadHoldingRegisters(addressInversor, 1);
            int[] Dir = modbus.ReadHoldingRegisters(addressDireta, 1);

            if (Soft[0] != 0 || Inv[0] != 0 || Dir[0] != 0)
            {
                this.Invoke((MethodInvoker)delegate { bt_motor.Text = "PARAR"; });
                this.Invoke((MethodInvoker)delegate { lb_color.BackColor = Color.Lime; });
            }
            else
            {
                this.Invoke((MethodInvoker)delegate { bt_motor.Text = "ACIONAR"; });
                this.Invoke((MethodInvoker)delegate { lb_color.BackColor = Color.Red; });
            }

            Dado dado = new Dado();
            dado.instante = DateTime.Now;
            dado.leituraVazao = fluxo;
            dado.leituraNivel = Nivel;
            dado.leituraFrequencia = FreqInt[0] / 10;
            dado.leituraTorque = Torque;
            using (StreamWriter sw = new StreamWriter("dados.txt", true))
            {
                sw.WriteLine(JsonConvert.SerializeObject(dado));
            }
        }

        /* Função referente ao click no botão "ACIONAR" OU "PARAR" do motor: Faz o acionamento ou desligamento do motor
         * Entradas: padrão
         * Saídas: nenhuma
         */
        private void bt_motor_Click(object sender, EventArgs e)
        {
            if (!modbus.Connected)
            {
                MessageBox.Show("Você deve se conectar ao ModBus antes de acionar o Motor!");
                return;
            }

            int addressSoft = 1316;
            int addressInversor = 1312;
            int addressDireta = 1319;
            int addressSeletor = 1324;

            int[] Soft = modbus.ReadHoldingRegisters(addressSoft, 1);
            int[] Inv = modbus.ReadHoldingRegisters(addressInversor, 1);
            int[] Dir = modbus.ReadHoldingRegisters(addressDireta, 1);

            if (bt_motor.Text == "ACIONAR")
            {
            
                if (Soft[0] != 0 || Inv[0] != 0 || Dir[0] != 0)
                {
                    MessageBox.Show("O MOTOR JÁ ESTÁ ACIONADO!");
                    return;
                }
                if (modbus.ReadHoldingRegisters(addressSeletor, 1)[0]!=2)
                    modbus.WriteSingleRegister(addressSeletor, 2);
                modbus.WriteSingleRegister(addressInversor, 1);
                lb_color.BackColor = Color.Lime;
            }
            else
            {
                if (Soft[0] != 0)
                {
                    modbus.WriteSingleRegister(addressSoft, 0);
                }
                if (Inv[0] != 0)
                {
                    modbus.WriteSingleRegister(addressInversor, 0);
                }
                if (Dir[0] != 0)
                {
                    modbus.WriteSingleRegister(addressDireta, 0);
                }
                lb_color.BackColor = Color.Red;
            }
        }

         private void dadoÚnicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpcoesRecuperacao recup = new OpcoesRecuperacao(false);
            recup.Show();
        }

        private void gráficoTempoRealToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (modbus.Connected)
            {
                graficos.Add (new Grafico(modbus));
                graficos.Last().Show();
               
            }
            else
            {
                MessageBox.Show("Você deve se conectar ao ModBus antes acessar os graficos");
            }
        }

        private void gráficoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpcoesRecuperacao recup = new OpcoesRecuperacao(true);
            recup.Show();
        }

        private void track_freq_Scroll(object sender, EventArgs e)
        {
            int addressFreq = 1313;
            if (!modbus.Connected)
            {
                MessageBox.Show("Você deve se conectar ao ModBus antes de alterar a frequência do motor");
                return;
            }
            modbus.WriteSingleRegister(addressFreq, track_freq.Value*10);
        }
    }

    /* Esta classe tem como objetivo organizar um formato para os dados de leitura.
     */
    public class Dado
    {
        public DateTime instante { get; set; }
        public float leituraVazao { get; set; }
        public float leituraNivel { get; set; }
        public int leituraFrequencia { get; set; }
        public float leituraTorque { get; set; }
    }
}
