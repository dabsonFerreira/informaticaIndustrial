﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EasyModbus;

namespace TrabalhoFinal
{
    /* Este formulário tem como objetivo configurar o objeto ModBus que será intermédio
     * da comunicação neste trabalho.
     */
    public partial class FormConfigModbus : Form
    {
        private ModbusClient modbus;    //Objeto de configuração desta classe
        private int taxa;               //Taxa de atualização do ModBus, a ser configurada

        /*Função do construtor: inicializa o Form atual, instancia o ModBus e configura o timer
         * Entradas: ModBus e Timer, vindos do Form principal
         * Saídas: nenhuma
         */
        public FormConfigModbus(ModbusClient mbc, Timer timer1)
        {
            InitializeComponent();
            this.modbus = mbc;  //Vai levando a referência do modbus que está vai ser configurada
            Int32.TryParse(tb_update.Text, out taxa);
            timer1.Interval = taxa;
        }

        /*Função de Validação do IPv4: retorna se o endereço IP passado como parâmetro é válido
         * Entrada: String contendo endereço IP com os campos separados por pontos.
         * Saída: verdadeiro se válido, falso se não
         */
        public bool ValidadeIPV4(string ipString)
        {
            if (String.IsNullOrWhiteSpace(ipString))
            {
                return false;
            }
            string[] splitValues = ipString.Split('.');
            if (splitValues.Length != 4)
            {
                return false;
            }
            byte tempForParsing;
            return splitValues.All(r => byte.TryParse(r, out tempForParsing));
        }

        /* Função referente ao evendo do "click" no botão "Configurar o ModBus":
         * Valida IP, porta e taxa de atualização e configura os parâmetros do ModBus
         * Entradas: padrão
         * Saídas: nenhuma*/
        private void bt_connect_Click(object sender, EventArgs e)
        {
            short port, taxa;
            try
            {
                if (ValidadeIPV4(this.tb_ip.Text) && Int16.TryParse(tb_porta.Text, out port) && Int16.TryParse(tb_update.Text, out taxa))
                {
                    this.modbus.IPAddress = tb_ip.Text;
                    this.modbus.Port = port;
                    this.modbus.ConnectionTimeout = taxa;
                    
                    MessageBox.Show("ModBus configurado com sucesso.");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("IP ou porta ou taxa inválidos! Preencha novamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.ToString());
            }
        }
    }
}
