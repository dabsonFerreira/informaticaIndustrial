﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrabalhoFinal
{
    public partial class GraficoRecuperacao : Form
    {
        List<Dado> dados;
        List<DateTime> instantes;
        public GraficoRecuperacao(List<Dado> d, List<DateTime> datas)
        {
            InitializeComponent();
            dados = d;
            instantes = datas;
            chart1.Series[0].Name = "Dados recuperados";
        }

        private void bt_torquegraf_Click(object sender, EventArgs e)
        {
            chart1.Series[0].Points.Clear();
            for(int i = 0; i < dados.Count; i++)
            {
                chart1.Series[0].Points.AddXY(instantes[i].ToString(), dados[i].leituraTorque);
            }
        }

        private void bt_freqgraf_Click(object sender, EventArgs e)
        {
            chart1.Series[0].Points.Clear();
            for (int i = 0; i < dados.Count; i++)
            {
                chart1.Series[0].Points.AddXY(instantes[i].ToString(), dados[i].leituraFrequencia);
            }

        }

        private void bt_vazaograf_Click(object sender, EventArgs e)
        {
            chart1.Series[0].Points.Clear();
            for (int i = 0; i < dados.Count; i++)
            {
                chart1.Series[0].Points.AddXY(instantes[i].ToString(), dados[i].leituraVazao);
            }

        }

        private void bt_nivelgraf_Click(object sender, EventArgs e)
        {
            chart1.Series[0].Points.Clear();
            for (int i = 0; i < dados.Count; i++)
            {
                chart1.Series[0].Points.AddXY(instantes[i].ToString(), dados[i].leituraNivel);
            }


        }
    }
}
