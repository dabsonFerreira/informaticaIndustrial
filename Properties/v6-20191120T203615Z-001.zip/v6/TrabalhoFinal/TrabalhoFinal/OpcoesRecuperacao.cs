﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace TrabalhoFinal
{
    public partial class OpcoesRecuperacao : Form
    {
        private Dictionary<string,Dado> dados;
        private bool ehGrafico;
        public OpcoesRecuperacao(bool grafico)
        {
            ehGrafico = grafico;
            InitializeComponent();
            dados = new Dictionary<string, Dado>();
            if (!grafico)
            {
                tb_ano2.Enabled = false;
                tb_mes2.Enabled = false;
                tb_dia2.Enabled = false;
                tb_hora2.Enabled = false;
                tb_min2.Enabled = false;
                tb_seg2.Enabled = false;
            }
            try
            {
                using (StreamReader sr = new StreamReader("dados.txt"))
                {
                    string leitura;
                    while (!sr.EndOfStream)
                    {
                        leitura = sr.ReadLine();
                        Dado objeto = JsonConvert.DeserializeObject<Dado>(leitura);
                        try
                        {
                            dados.Add(objeto.instante.ToString(), objeto);
                        }
                        catch(Exception ex)
                        {
                            if (ex.Message != "Já foi adicionado um item com a mesma chave.")
                                throw new System.Exception(ex.Message);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro ao ler o arquivo: " + ex.Message);
                this.Close();
            }
        }

        private void bt_recup_Click(object sender, EventArgs e)
        {
            if (!ehGrafico)
            {
                try
                {
                    DateTime chaveBusca = new DateTime(Convert.ToInt32(tb_ano.Text), Convert.ToInt32(tb_mes.Text), Convert.ToInt32(tb_dia.Text),
                        Convert.ToInt32(tb_hora.Text), Convert.ToInt32(tb_min.Text), Convert.ToInt32(tb_seg.Text));
                    Dado busca = dados[chaveBusca.ToString()];
                    MessageBox.Show("Dados para o dia e hora " + busca.instante.ToString() + 
                        "\n Leitura Vazao: " + busca.leituraVazao.ToString()+
                        "\n Leitura Nivel: " + busca.leituraNivel.ToString()+
                        "\n Leitura Frequencia: " + busca.leituraFrequencia.ToString() +
                        "\n Leitura Torque: " + busca.leituraTorque.ToString());
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Erro ao ler dado... Pode ser que o dado pra esse instante de tempo nao exista!\n Erro: " + ex.Message);
                }
            }
            else
            {
                try
                {
                    DateTime chaveBusca = new DateTime(Convert.ToInt32(tb_ano.Text), Convert.ToInt32(tb_mes.Text), Convert.ToInt32(tb_dia.Text),
                        Convert.ToInt32(tb_hora.Text), Convert.ToInt32(tb_min.Text), Convert.ToInt32(tb_seg.Text));
                    DateTime chaveBusca2 = new DateTime(Convert.ToInt32(tb_ano2.Text), Convert.ToInt32(tb_mes2.Text), Convert.ToInt32(tb_dia2.Text),
                        Convert.ToInt32(tb_hora2.Text), Convert.ToInt32(tb_min2.Text), Convert.ToInt32(tb_seg2.Text));
                    DateTime data1 = Convert.ToDateTime(chaveBusca);
                    DateTime data2 = Convert.ToDateTime(chaveBusca2);
                    int comparacao = DateTime.Compare(data1, data2);
                    if (comparacao >= 0)
                    {
                        MessageBox.Show("A data inicial é igual ou posterior que a data final.");
                        return;
                    }
                    List<Dado> plot = new List<Dado>();
                    List<DateTime> instantes = new List<DateTime>();
                    plot.Add(dados[data1.ToString()]);
                    instantes.Add(data1);
                    while(data1 != data2)
                    {
                        data1 = data1.AddSeconds(1);
                        try
                        {
                            plot.Add(dados[data1.ToString()]);
                            instantes.Add(data1);
                        }
                        catch
                        {

                        }
                    }
                    plot.Add(dados[data2.ToString()]);
                    instantes.Add(data2);

                    GraficoRecuperacao gr = new GraficoRecuperacao(plot, instantes);
                    gr.Show();
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
            }
        }
    }
}
