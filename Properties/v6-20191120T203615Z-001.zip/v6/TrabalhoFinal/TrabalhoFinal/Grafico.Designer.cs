﻿namespace TrabalhoFinal
{
    partial class Grafico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.bt_nivelgraf = new System.Windows.Forms.Button();
            this.bt_vazaograf = new System.Windows.Forms.Button();
            this.bt_freqgraf = new System.Windows.Forms.Button();
            this.bt_torquegraf = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_nivelgraf
            // 
            this.bt_nivelgraf.Location = new System.Drawing.Point(894, 424);
            this.bt_nivelgraf.Margin = new System.Windows.Forms.Padding(4);
            this.bt_nivelgraf.Name = "bt_nivelgraf";
            this.bt_nivelgraf.Size = new System.Drawing.Size(109, 55);
            this.bt_nivelgraf.TabIndex = 20;
            this.bt_nivelgraf.Text = "NÍVEL";
            this.bt_nivelgraf.UseVisualStyleBackColor = true;
            this.bt_nivelgraf.Click += new System.EventHandler(this.bt_nivelgraf_Click);
            // 
            // bt_vazaograf
            // 
            this.bt_vazaograf.Location = new System.Drawing.Point(894, 295);
            this.bt_vazaograf.Margin = new System.Windows.Forms.Padding(4);
            this.bt_vazaograf.Name = "bt_vazaograf";
            this.bt_vazaograf.Size = new System.Drawing.Size(109, 55);
            this.bt_vazaograf.TabIndex = 19;
            this.bt_vazaograf.Text = "VAZÃO";
            this.bt_vazaograf.UseVisualStyleBackColor = true;
            this.bt_vazaograf.Click += new System.EventHandler(this.bt_vazaograf_Click);
            // 
            // bt_freqgraf
            // 
            this.bt_freqgraf.Location = new System.Drawing.Point(894, 172);
            this.bt_freqgraf.Margin = new System.Windows.Forms.Padding(4);
            this.bt_freqgraf.Name = "bt_freqgraf";
            this.bt_freqgraf.Size = new System.Drawing.Size(109, 55);
            this.bt_freqgraf.TabIndex = 18;
            this.bt_freqgraf.Text = "FREQUÊNCIA";
            this.bt_freqgraf.UseVisualStyleBackColor = true;
            this.bt_freqgraf.Click += new System.EventHandler(this.bt_freqgraf_Click);
            // 
            // bt_torquegraf
            // 
            this.bt_torquegraf.Location = new System.Drawing.Point(894, 49);
            this.bt_torquegraf.Margin = new System.Windows.Forms.Padding(4);
            this.bt_torquegraf.Name = "bt_torquegraf";
            this.bt_torquegraf.Size = new System.Drawing.Size(109, 55);
            this.bt_torquegraf.TabIndex = 13;
            this.bt_torquegraf.Text = "TORQUE";
            this.bt_torquegraf.UseVisualStyleBackColor = true;
            this.bt_torquegraf.Click += new System.EventHandler(this.bt_torquegraf_Click);
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(26, 17);
            this.chart1.Margin = new System.Windows.Forms.Padding(4);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(801, 488);
            this.chart1.TabIndex = 12;
            this.chart1.Text = "chart1";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Grafico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 518);
            this.Controls.Add(this.bt_nivelgraf);
            this.Controls.Add(this.bt_vazaograf);
            this.Controls.Add(this.bt_freqgraf);
            this.Controls.Add(this.bt_torquegraf);
            this.Controls.Add(this.chart1);
            this.Name = "Grafico";
            this.Text = "Grafico";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_nivelgraf;
        private System.Windows.Forms.Button bt_vazaograf;
        private System.Windows.Forms.Button bt_freqgraf;
        private System.Windows.Forms.Button bt_torquegraf;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Timer timer1;
    }
}