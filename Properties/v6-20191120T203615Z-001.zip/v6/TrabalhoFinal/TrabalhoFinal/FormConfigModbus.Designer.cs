﻿namespace TrabalhoFinal
{
    partial class FormConfigModbus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_ip = new System.Windows.Forms.Label();
            this.lb_porta = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_ip = new System.Windows.Forms.TextBox();
            this.tb_porta = new System.Windows.Forms.TextBox();
            this.tb_update = new System.Windows.Forms.TextBox();
            this.bt_connect = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_ip
            // 
            this.lb_ip.AutoSize = true;
            this.lb_ip.Location = new System.Drawing.Point(60, 34);
            this.lb_ip.Name = "lb_ip";
            this.lb_ip.Size = new System.Drawing.Size(17, 13);
            this.lb_ip.TabIndex = 0;
            this.lb_ip.Text = "IP";
            this.lb_ip.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_porta
            // 
            this.lb_porta.AutoSize = true;
            this.lb_porta.Location = new System.Drawing.Point(52, 68);
            this.lb_porta.Name = "lb_porta";
            this.lb_porta.Size = new System.Drawing.Size(32, 13);
            this.lb_porta.TabIndex = 1;
            this.lb_porta.Text = "Porta";
            this.lb_porta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(32, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 27);
            this.label3.TabIndex = 2;
            this.label3.Text = "Taxa de Atualização";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tb_ip
            // 
            this.tb_ip.Location = new System.Drawing.Point(121, 31);
            this.tb_ip.Name = "tb_ip";
            this.tb_ip.Size = new System.Drawing.Size(100, 20);
            this.tb_ip.TabIndex = 3;
            this.tb_ip.Text = "10.15.20.17";
            this.tb_ip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_porta
            // 
            this.tb_porta.Location = new System.Drawing.Point(121, 65);
            this.tb_porta.Name = "tb_porta";
            this.tb_porta.Size = new System.Drawing.Size(100, 20);
            this.tb_porta.TabIndex = 4;
            this.tb_porta.Text = "10013";
            this.tb_porta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_update
            // 
            this.tb_update.Location = new System.Drawing.Point(121, 103);
            this.tb_update.Name = "tb_update";
            this.tb_update.Size = new System.Drawing.Size(100, 20);
            this.tb_update.TabIndex = 5;
            this.tb_update.Text = "1000";
            this.tb_update.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bt_connect
            // 
            this.bt_connect.Location = new System.Drawing.Point(55, 148);
            this.bt_connect.Name = "bt_connect";
            this.bt_connect.Size = new System.Drawing.Size(166, 34);
            this.bt_connect.TabIndex = 6;
            this.bt_connect.Text = "Configurar o ModBus";
            this.bt_connect.UseVisualStyleBackColor = true;
            this.bt_connect.Click += new System.EventHandler(this.bt_connect_Click);
            // 
            // FormConfigModbus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 203);
            this.Controls.Add(this.bt_connect);
            this.Controls.Add(this.tb_update);
            this.Controls.Add(this.tb_porta);
            this.Controls.Add(this.tb_ip);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lb_porta);
            this.Controls.Add(this.lb_ip);
            this.Name = "FormConfigModbus";
            this.Text = "Configuração da Conexão";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_ip;
        private System.Windows.Forms.Label lb_porta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_ip;
        private System.Windows.Forms.TextBox tb_porta;
        private System.Windows.Forms.TextBox tb_update;
        private System.Windows.Forms.Button bt_connect;
    }
}