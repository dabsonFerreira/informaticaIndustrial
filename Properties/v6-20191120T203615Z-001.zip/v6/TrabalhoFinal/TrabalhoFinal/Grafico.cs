﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using EasyModbus;
using Newtonsoft.Json;

namespace TrabalhoFinal
{
    public partial class Grafico : Form
    {
        ModbusClient modbus;

        private delegate void AtualizaGraficoDelegate(float dado);
        private delegate void DisableDelegate();
        private AtualizaGraficoDelegate AtualizaG;
        int opcaoatual = 0;

        public Grafico(ModbusClient modbus)
        {
            this.modbus = modbus;
            InitializeComponent();
            AtualizaG = new AtualizaGraficoDelegate(AtualizaGrafico);
            timer1.Interval = 1000;
            timer1.Enabled = true;
            chart1.Series[0].Name = "";

        }

        public float lerdados()
        {
            int addressFluxo = 712;
            int addressNivel = 714;
            int addressTorque = 1334;
            int addressFreq = 1313;

            switch (opcaoatual)
            {

                case 1:
                    int[] fluxoInt = modbus.ReadHoldingRegisters(addressFluxo, 2);
                    return ModbusClient.ConvertRegistersToFloat(fluxoInt, ModbusClient.RegisterOrder.LowHigh);


                case 2:

                    int[] NivelInt = modbus.ReadHoldingRegisters(addressNivel, 2);
                    return ModbusClient.ConvertRegistersToFloat(NivelInt, ModbusClient.RegisterOrder.LowHigh);


                case 3:

                    int[] TorqueInt = modbus.ReadHoldingRegisters(addressTorque, 2);
                    return ModbusClient.ConvertRegistersToFloat(TorqueInt, ModbusClient.RegisterOrder.LowHigh);


                case 4:

                    int[] FreqInt = modbus.ReadHoldingRegisters(addressFreq, 1);
                    return (float)FreqInt[0] / 10;

            }

            return 0;
         }

        public void AtualizaGrafico(float dado)
        {
            chart1.Series[0].Points.Add(dado);
        }

        /*public void disable()
        {
            try
            {
                if(modbus.Connected)
                    
            }
        }*/



        private void timer1_Tick(object sender, EventArgs e)
        {
            if (opcaoatual != 0)
            {
                try
                {
                    this.chart1.Invoke(AtualizaG, lerdados());
                }

                catch(Exception ex)
                {
                    MessageBox.Show("Erro de conexão:" + ex.Message);
                }
            }
            
        }

        private void bt_torquegraf_Click(object sender, EventArgs e)
        {
            chart1.Titles.Clear();
            chart1.Titles.Add("Torque");
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Name = "Torque";
            opcaoatual = 3;
        }

        private void bt_freqgraf_Click(object sender, EventArgs e)
        {
            chart1.Titles.Clear();
            chart1.Titles.Add("Frequência");
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Name = "Frequência";
            opcaoatual = 4;
        }

        private void bt_vazaograf_Click(object sender, EventArgs e)
        {
            chart1.Titles.Clear();
            chart1.Titles.Add("Vazão");
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Name = "Vazão";
            opcaoatual = 1;
        }

        private void bt_nivelgraf_Click(object sender, EventArgs e)
        {
            chart1.Titles.Clear();
            chart1.Titles.Add("Nível do Tanque");
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Name = "Nível";
            opcaoatual = 2;
        }
    }
}
